package com.saucedemo.tasks;

import com.saucedemo.ui.SwagLabsUI;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;

public class CompletarCheckout implements Task {

    private final String nombre;
    private final String apellido;
    private final String codigoPostal;

    public CompletarCheckout(String nombre, String apellido, String codigoPostal) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.codigoPostal = codigoPostal;
    }

    public static CompletarCheckout conDatos(String nombre, String apellido, String codigoPostal) {
        return Tasks.instrumented(CompletarCheckout.class, nombre, apellido, codigoPostal);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Click.on(SwagLabsUI.BTN_CHECKOUT),
                Enter.theValue(nombre).into(SwagLabsUI.FIRST_NAME),
                Enter.theValue(apellido).into(SwagLabsUI.LAST_NAME),
                Enter.theValue(codigoPostal).into(SwagLabsUI.POSTAL_CODE),
                Click.on(SwagLabsUI.BTN_CONTINUE)
        );
    }
}
