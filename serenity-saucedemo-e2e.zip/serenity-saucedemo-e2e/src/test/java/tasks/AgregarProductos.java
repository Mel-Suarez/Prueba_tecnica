package com.saucedemo.tasks;

import com.saucedemo.ui.SwagLabsUI;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.Tasks;

public class AgregarProductos implements Task {

    public static AgregarProductos dos() {
        return Tasks.instrumented(AgregarProductos.class);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Click.on(SwagLabsUI.BTN_ADD_BACKPACK),
                Click.on(SwagLabsUI.BTN_ADD_BIKE_LIGHT)
        );
    }
}
