package com.saucedemo.tasks;

import com.saucedemo.ui.SwagLabsUI;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;

public class FinalizarCompra implements Task {

    public static FinalizarCompra ahora() {
        return Tasks.instrumented(FinalizarCompra.class);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Click.on(SwagLabsUI.BTN_FINISH)
        );
    }
}
