package com.saucedemo.tasks;

import com.saucedemo.ui.SwagLabsUI;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Enter;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.Tasks;

public class Autenticarse implements Task {

    private final String usuario;
    private final String clave;

    public Autenticarse(String usuario, String clave) {
        this.usuario = usuario;
        this.clave = clave;
    }

    public static Autenticarse con(String usuario, String clave) {
        return Tasks.instrumented(Autenticarse.class, usuario, clave);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Enter.theValue(usuario).into(SwagLabsUI.USERNAME),
                Enter.theValue(clave).into(SwagLabsUI.PASSWORD),
                Click.on(SwagLabsUI.BTN_LOGIN)
        );
    }
}
