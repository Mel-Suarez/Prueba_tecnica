package com.saucedemo.tasks;

import com.saucedemo.ui.SwagLabsUI;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;

public class VisualizarCarrito implements Task {

    public static VisualizarCarrito ahora() {
        return Tasks.instrumented(VisualizarCarrito.class);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Click.on(SwagLabsUI.CART_ICON)
        );
    }
}
