package com.saucedemo.ui;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class SwagLabsUI {

    // Login
    public static final Target USERNAME = Target.the("campo usuario")
            .located(By.id("user-name"));
    public static final Target PASSWORD = Target.the("campo password")
            .located(By.id("password"));
    public static final Target BTN_LOGIN = Target.the("botón Login")
            .located(By.id("login-button"));

    // Inventario (productos)
    public static final Target BTN_ADD_BACKPACK = Target.the("Add to cart - Backpack")
            .located(By.id("add-to-cart-sauce-labs-backpack"));
    public static final Target BTN_ADD_BIKE_LIGHT = Target.the("Add to cart - Bike light")
            .located(By.id("add-to-cart-sauce-labs-bike-light"));
    public static final Target CART_ICON = Target.the("icono del carrito")
            .located(By.cssSelector(".shopping_cart_link"));
    public static final Target CART_BADGE = Target.the("contador del carrito")
            .located(By.cssSelector(".shopping_cart_badge"));

    // Carrito
    public static final Target TITLE_GENERIC = Target.the("título de página")
            .located(By.cssSelector(".title")); // se usa en varias vistas

    public static final Target BTN_CHECKOUT = Target.the("botón Checkout")
            .located(By.id("checkout"));

    // Checkout: your information
    public static final Target FIRST_NAME = Target.the("nombre")
            .located(By.id("first-name"));
    public static final Target LAST_NAME = Target.the("apellido")
            .located(By.id("last-name"));
    public static final Target POSTAL_CODE = Target.the("código postal")
            .located(By.id("postal-code"));
    public static final Target BTN_CONTINUE = Target.the("botón Continue")
            .located(By.id("continue"));

    // Checkout: overview
    public static final Target BTN_FINISH = Target.the("botón Finish")
            .located(By.id("finish"));

    // Confirmación
    public static final Target COMPLETE_HEADER = Target.the("mensaje de confirmación")
            .located(By.cssSelector(".complete-header")); // "THANK YOU FOR YOUR ORDER"
}
