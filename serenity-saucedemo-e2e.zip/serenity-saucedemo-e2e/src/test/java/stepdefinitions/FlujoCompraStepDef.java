package com.saucedemo.stepdefinitions;
import com.saucedemo.ui.SwagLabsUI;

import io.cucumber.java.Before;
import io.cucumber.java.es.*;
import net.serenitybdd.annotations.Managed;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.serenitybdd.screenplay.actions.Open;
import net.serenitybdd.screenplay.ensure.Ensure;
import org.openqa.selenium.WebDriver;


public class FlujoCompraStepDef {

    @Managed(driver = "chrome")
    WebDriver navegador;
    Actor usuario;

    @Before
    public void setUp() {
        usuario = Actor.named("Comprador");
        usuario.can(BrowseTheWeb.with(navegador));
    }

    @Dado("que estoy en la página de Saucedemo")
    public void abrirPagina() {
        usuario.attemptsTo(Open.url("https://www.saucedemo.com/"));
    }

    @Cuando("inicio sesión con usuario {string} y clave {string}")
    public void login(String user, String pass) {
        usuario.attemptsTo(com.saucedemo.tasks.Autenticarse.con(user, pass));
    }

    @Cuando("agrego dos productos al carrito")
    public void agregarProductos() {
        usuario.attemptsTo(com.saucedemo.tasks.AgregarProductos.dos());
    }

    @Cuando("visualizo el carrito")
    public void verCarrito() {
        usuario.attemptsTo(com.saucedemo.tasks.VisualizarCarrito.ahora());
    }

    @Cuando("completo el formulario de compra con {string} {string} {string}")
    public void completarFormulario(String nombre, String apellido, String codigo) {
        usuario.attemptsTo(com.saucedemo.tasks.CompletarCheckout.conDatos(nombre, apellido, codigo));
    }

    @Cuando("finalizo la compra")
    public void finalizarCompra() {
        usuario.attemptsTo(com.saucedemo.tasks.FinalizarCompra.ahora());
    }

    @Entonces("debo ver el mensaje {string}")
    public void validarMensaje(String mensaje) {
        usuario.attemptsTo(Ensure.that(SwagLabsUI.COMPLETE_HEADER).text().isEqualTo(mensaje));
    }
}
