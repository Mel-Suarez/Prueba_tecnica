describe("Iniciar sesión en Demoblaze", () => {
  it("Crear una cuenta", () => {
    cy.visit('https://www.demoblaze.com/index.html');

    // Hacer clic en el botón real de navegación "Sign up"
    cy.get('#signin2').click(); // Este es el botón que abre el modal

    // Esperar a que el modal esté visible
    cy.get('#signInModal').should('have.class', 'show');

    // Esperar a que el campo de usuario esté visible
   cy.get('#sign-username', { timeout: 10000 })
  .should('be.visible');

cy.wait(1000); // espera 

cy.get('#sign-username')
  .type('pruebas' + Date.now());

cy.get('#sign-password')
  .type('123456789');

    // Hacer clic en el botón "Sign up" del modal
    cy.get('button[onclick="register()"]').click();

    // Verificar que se muestre la alerta de éxito 
    cy.on('window:alert', (text) => {
      expect(text).to.contains('Sign up successful.');
    });

    // Esperar un momento para que el modal se cierre 
    cy.wait(1000);
    
  });
});

describe("Intentar crear un usuario ya existente", () => {
  it("Crear una cuenta existente", () => {
    cy.visit('https://www.demoblaze.com/index.html');

    // Hacer clic en el botón real de navegación "Sign up"
    cy.get('#signin2').click(); 

    // Esperar a que el modal esté visible
    cy.get('#signInModal').should('have.class', 'show');

    // Esperar a que el campo de usuario esté visible
    cy.get('#sign-username', { timeout: 10000 })
      .should('be.visible');

    cy.wait(1000); 

    cy.get('#sign-username')
      .type('pruebas' + Date.now()); // Usuario ya existente

    cy.get('#sign-password')
      .type('123456789');

    // Hacer clic en el botón "Sign up" del modal
    cy.get('button[onclick="register()"]').click();

    // Verificar que se muestre la alerta de error
    cy.on('window:alert', (text) => {
    console.log('Alerta recibida:', text);
    expect(
      text === 'Sign up successful.' || text === 'This user already exist.'
    ).to.be.true;
});

  });
});


