describe('Agregar productos al carrito en Demoblaze', () => {
  it('Debe agregar dos productos al carrito', () => {
    //Visitar la página
    cy.visit('https://www.demoblaze.com/index.html');

    //eleccionar el primer producto
    cy.contains('Samsung galaxy s6').click();

    //Agregar al carrito
    cy.contains('Add to cart').click();

    // Esperar a que aparezca la alerta y aceptarla
    cy.on('window:alert', (text) => {
      expect(text).to.contains('Product added');
    });

    cy.wait(1000); // Esperar a que se procese el click

    cy.contains('Home').click();

    //Seleccionar el segundo producto
    cy.contains('Nokia lumia 1520').click();

    cy.contains('Add to cart').click();

    cy.on('window:alert', (text) => {
      expect(text).to.contains('Product added');
    });

    cy.wait(1000);

    // Ir al carrito
    cy.contains('Cart').click();

    // Verificar que hay dos productos en el carrito
    cy.get('#tbodyid > tr').should('have.length', 2);

    // Realizar la compra
    cy.contains('Place Order').click();

    // Completar el formulario de compra
    cy.get('#name').type('Melany Suarez');
    cy.get('#country').type('Ecuador'); 
    cy.get('#city').type('Guayaquil');
    cy.get('#card').type('1234567890123456');
    cy.get('#month').type('12');
    cy.get('#year').type('2028');

    // Finalizar la compra
    cy.contains('Purchase').click();

  });
});
