
describe("Login con usuario existente", () => {
  it("Iniciar sesión con usuario existente", () => {
    cy.visit('https://www.demoblaze.com/index.html');

    // Hacer clic en el botón real de navegación "Log in"
    cy.get('#login2').click(); 

    // Esperar a que el modal esté visible
    cy.get('#logInModal').should('have.class', 'show');

    // Esperar a que el campo de usuario esté visible
    cy.get('#loginusername', { timeout: 10000 })
      .should('be.visible');

    cy.wait(1000); // espera 

    cy.get('#loginusername')
      .type('pruebas' + Date.now()); // Usuario existente

    cy.get('#loginpassword')
      .type('123456789');

    // Hacer clic en el botón "Log in" del modal
    cy.get('button[onclick="logIn()"]').click();

    // Verificar que se muestre la alerta de éxito
    cy.on('window:alert', (text) => {
      expect(text).to.contains('Welcome');
    });

  });
});

describe("Intentar iniciar sesión con usuario no existente", () => {
  it("Iniciar sesión con usuario no existente", () => {
    cy.visit('https://www.demoblaze.com/index.html');

    // Hacer clic en el botón real de navegación "Log in"
    cy.get('#login2').click(); 

    // Esperar a que el modal esté visible
    cy.get('#logInModal').should('have.class', 'show');

    // Esperar a que el campo de usuario esté visible
    cy.get('#loginusername', { timeout: 10000 })
      .should('be.visible');

    cy.wait(1000); // espera 

    cy.get('#loginusername')
      .type('usuario_nuevo'); // Usuario no existente

    cy.get('#loginpassword')
      .type('12345');

    // Hacer clic en el botón "Log in" del modal
    cy.get('button[onclick="logIn()"]').click();

    // Verificar que se muestre la alerta de error
    cy.on('window:alert', (text) => {
      expect(text).to.contains('User does not exist.');
    });


  });
});
