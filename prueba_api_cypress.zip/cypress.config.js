const { defineConfig } = require('cypress');

module.exports = defineConfig({
  e2e: {
    baseUrl: 'https://www.demoblaze.com',
    defaultCommandTimeout: 10000, // espera por comando
    pageLoadTimeout: 60000,       // espera por carga de página
    setupNodeEvents(on, config) {
      return config;
    },
  },
});
 
